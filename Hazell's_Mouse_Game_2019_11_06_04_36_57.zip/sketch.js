/////////
// SCENE 1
// VARIABLES
///////// 
let scene1 = true;  
//snake variables 
var offset = 5; //how fast the snake goes
var strum = 1; 
var squirm = 0.1; // decrease for less waves, increase for more waves
//min and max for how tall the snake is
var yMin = 350; 
var yMax = 375; 
var greenColor = 255; // snake color 
var canDrawText1 = false; //boolean to display the snake text
var time1 = 0; //the timer for displaying feed me text
var snaketouch = 0;// for text to appear feed me
var firstclick = 0;
var clickChecked = false; 
var time3 = 0; // timer for the kids text
var canDrawText3 = false; //can draw the kids text

let books1;
let kid1; 
//let text1; 


/////////
// SCENE 2 
// VARIABLES
/////////

let scene2 = false; //check if scene2 should be active
let mouse1, mouse2, mouse3, mouse4; 
let kid2; 
let train; 
let totalMouse; //global variable of how many mice we've collected !
let pTotalMouse; //check previous totalMouse
let collect; //use in mouse class
let canDrawText2; //use in mouseclass 
let time2; //use in mouse class 

/////////
// SCENE 3  
// VARIABLES
/////////

let scene3 = false;

/////////
// SCENE 4
// VARIABLES 
/////////

let scene4 = false;
var yumCounter = 0; 



/////////
// SETUP
// (FOR ALL SCENES) 
/////////

function setup() {
  createCanvas(400, 400); 

  mouse1 = new Mouse(150, 190); 
  mouse2 = new Mouse(0, 150); 
  mouse3 = new Mouse(350, 350);  
  mouse4 = new Mouse(250, 40); 

  m2Collected = false; 
  totalMouse = 0; 

  kid1 = new Kid(); 
  kid2 = new Kid();
  books1 = new Books(); 
}

/////////
// DRAW
// SCENE 1
/////////

function draw() { 
  if (scene1) { 
    background(166, 136, 186);  
    books1.show(); 
   
  
  
    kid1.show(); 
    
    print(firstclick);
    
    if (firstclick == 1){
      if (!clickChecked) { 
      canDrawText3 = true;
      time3 = millis();
        clickChecked = true;
      }
  
  }
    
     //display the kid's text
    if (canDrawText3) {
      //if it hasn't been 4 seconds, then print feed me text
      if (millis() < time3 + 4000) { 
        print("time = " + time3); 
        // print("millis = " + millis());
        fill(0);  
        stroke(0); 
        strokeWeight(1); 
        drawText3();  
      } else {  
        canDrawText3 = false;
      }
    }
   

    


    drawSnake(); //call the snake

    //change snake color 
    if ((kid1.kidX +100 > 300 && kid1.kidX+100 < width - 25) && (kid1.kidY+50 > 300 && kid1.kidY+50< 375)) { // xhwxk if kid is touching snake
      greenColor = 215;// color change
      snaketouch ++;
      //do once
      if (snaketouch == 1) { 
         
      canDrawText1 = true;
      time1 = millis();// time of execution, to start timer
 
      }
    //print ("Feed Me"); 
    } else { 
      greenColor = 255; 
    }

    //display the snake's text
    if (canDrawText1) {
      //if it hasn't been 4 seconds, then print feed me text
      if (millis() < time1 + 4000) { 
        // print("time = " + time); 
        // print("millis = " + millis());
        fill(0); 
        stroke(0);  
        strokeWeight(1); 
        drawText1();  
      } else { //if it has been 6 seconds, stop drawing text
        /////////
        // SCENE 2
        // IS TRUE!!! 
        /////////
        scene2 = true; 
        canDrawText1 = false;

      }
    }


    if (keyIsDown(LEFT_ARROW)) {
      kid1.kidX -= 2;
    }

    if (keyIsDown(RIGHT_ARROW)) {
      kid1.kidX += 2;
    }

    if (keyIsDown(UP_ARROW)) {
      kid1.kidY -= 2;
    }

    if (keyIsDown(DOWN_ARROW)) {
      kid1.kidY += 2;
    }
  }

  if (totalMouse >= 4) {
    print("i here"); 
    scene3 = true;
    scene1 = false; 
    scene2 = false; 
  }

  /////////
  // SCENE 2 
  // SHOW WHAT IS IN DISPLAY FUNCTION
  /////////
  if (scene2) {
    scene1 = false;
    scene3 = false; 
    //display scene2 
    scene2Display(); 
  }
  /////////
  // SCENE 3
  // SHOW WHAT IS IN DISPLAY FUNCTION
  /////////
  if (scene3) {  
    scene1 = false; 
    scene2 = false; 
    //display scene 3 
    scene3Display(); 
  }
  
  if (scene4){
    
    scene1 = false;
    scene2 = false;
    scene3 = false;
    scene4Display();
  }
}

/////////
// SCENE 2
// DRAW
/////////
function scene2Display() { 
  if (scene2) { 
    print(totalMouse);
    background(220); 
    drawrailroad(); //drawing railroad  

    kid2.show();

    mouse1.show();
    mouse1.move();  
    mouse1.checkCollision();
    mouse1.drawText(); 

    mouse2.show();
    mouse2.move();
    mouse2.checkCollision();
    mouse2.drawText();

    mouse3.show();
    mouse3.move(); 
    mouse3.checkCollision();
    mouse3.drawText();

    mouse4.show();
    mouse4.move();
    mouse4.checkCollision();
    mouse4.drawText();


    if (keyIsDown(LEFT_ARROW)) {
      kid2.kidX -= 2;
    }

    if (keyIsDown(RIGHT_ARROW)) {
      kid2.kidX += 2;
    }

    if (keyIsDown(UP_ARROW)) {
      kid2.kidY -= 2;
    }

    if (keyIsDown(DOWN_ARROW)) {
      kid2.kidY += 2;
    } 
  }
}

/////////
// SCENE 3
// DISPLAY
/////////

function scene3Display() {

   background(194, 151, 207);
  
  fill(77, 93, 125);
rect(0.5,140,410,8);
  stroke(0);
    strokeWeight(1);
  
    fill(77, 93, 125);
    rect(this.booksX - 70, this.booksY - 0.4, 410,4); //shelf
    

 
     fill(11, 14, 15);
    rect(158,80,185,10); 
    rect(151,130,200,10);
   
    rect(158,80,2,60);
    rect(340,80,2,60);
   
    fill(68, 128, 85);
    ellipse(190,113,20,10);//leaves
   ellipse(210,113,20,10);
  ellipse(200,119,10,20);
    ellipse(200,107,10,20);
    
   fill(77, 67, 40); //logs
   rect(220,124,50,5); 
    
    fill(120, 118, 114);
    ellipse(290,119,30,20);//rock
    
   fill(110, 10, 250);//books
  rect(1,40,20,100);
  fill(186, 3, 252);
  rect(20,60,20,80); 
  fill(252, 3, 20);
  rect(40,80,20,60);
  drawSnake();  
  kid2.show();
  print(yumCounter);

  //When bucket touches snake, snake says um num num 
  if ((kid2.kidX + 100 > 300 && kid2.kidY + 100 < width - 25) && (kid2.kidY + 200 > 350 && kid2.kidY + 100 < 375)) {
    greenColor = 215;
    yumCounter ++;
    drawText2();
  } else {
    greenColor = 255;
  } 
  
  if (yumCounter> 200){
    scene4 = true;
    scene3 = false;
    
  }
    
    
  if (keyIsDown(LEFT_ARROW)) {
    kid2.kidX -= 2;
  }

  if (keyIsDown(RIGHT_ARROW)) {
    kid2.kidX += 2;
  }

  if (keyIsDown(UP_ARROW)) {
    kid2.kidY -= 2;
  }

  if (keyIsDown(DOWN_ARROW)) {
    kid2.kidY += 2;
  }
}
//////////SCENE
function scene4Display(){
   background(55, 173, 191); 
  textSize(30);
  fill(227, 16, 51); 
  stroke(255);
  textFont('Arial Black');
  text("Toby Is Finally FED!",40,200); 
  ellipse(190,280,90,90); 
  
  fill(19, 20, 20);
  ellipse(170,270,20,20); // eyes
  ellipse(205,270,20,20);
  rect(177,300,20,3);
  rect(194,293,4,10);
   rect(174,293,4,10);
}

/////////
// SCENE 3
//UM NOM NOM TEXT
///////// 


function drawText2() { 
  textSize(14);
  textFont('Brisk');
  fill(2, 13, 0);
  text("YUM YUM!", 300, 275);
  fill(0);


}
/////////
// SCENE 1
// FOR SNAKE BUTTON
/////////
function mouseReleased() { 
  firstclick++;
}

function drawText3() { 
  textSize(14);
  fill(72, 32, 97);
  text("Time to check on Toby", kid1.kidX, kid1.kidY - 10);
  fill(0);


}

function drawrailroad() {
  background(215, 212, 217);
  fill(71, 67, 74);

  rect(240, 10, 10, 80);
  rect(200, 10, 10, 80);
  rect(60, 10, 10, 80);
  rect(100, 10, 10, 80);
  rect(264, 10, 10, 80);
  rect(300, 10, 10, 80);
  rect(320, 10, 10, 80);
  rect(380, 10, 10, 80);
  rect(354, 10, 10, 80);
  rect(354, 10, 10, 80);
  rect(129, 10, 10, 80);
  rect(160, 10, 10, 80);
  rect(23, 10, 10, 80);

  rect(3, 20, 400, 10);
  rect(3, 70, 400, 10);



  rect(240, 310, 10, 80);
  rect(200, 310, 10, 80);
  rect(60, 310, 10, 80);
  rect(100, 310, 10, 80);
  rect(264, 310, 10, 80);
  rect(300, 310, 10, 80);
  rect(320, 310, 10, 80);
  rect(380, 310, 10, 80);
  rect(354, 310, 10, 80);
  rect(354, 310, 10, 80);
  rect(129, 310, 10, 80);
  rect(160, 310, 10, 80);
  rect(23, 310, 10, 80);
  rect(3, 330, 400, 10); //horrizontal lines
  rect(3, 370, 400, 10); //horrizontal lines
}

  
  
/////////
// SCENE 1
// SNAKE FEED ME
/////////
function drawText1() { 
  textSize(12);
  fill(26, 8, 38); 
  text("FEED ME!", 300, 325); 
  fill(0); 
  
}

/////////
// SCENE 1
// DISPLAY SNAKE
/////////
function drawSnake() {
  //make a snake!
  strokeWeight(20); //how fat the snake is
  stroke(0, greenColor, 0); //color of the snake
  noFill(); //don't fill the incomplete shape

  //build line
  beginShape(); 

  for (var x = 300; x < width - 25; x++) { //modify x and condition to change placement on the x axis

    var angle = offset + x * squirm; //angle of how squirmy

    var y = map(sin(angle), -strum, strum, yMin, yMax); //build the snake
    vertex(x, y); //put it on the screen, display the vertexes (snake)
  }

  endShape();
  //end the line

  offset += 0.08; //bigger number, faster snake
}

/////////
// SCENE 1 AND 2
// USE KID IN BOTH SCENES
/////////

class Books {
  constructor(){
    this.booksX = width / 6;
    this.booksY = height - 260;
  
}
  show(){
    stroke(0);
    strokeWeight(1);
    fill(77, 93, 125);
    rect(this.booksX - 70, this.booksY - 0.4, 410,8); //shelf
    
    //snake tank
    fill(11, 14, 15);
    rect(158,80,185,10); 
    rect(151,130,200,10);
   
    rect(158,80,2,60);
    rect(340,80,2,60);
   
    fill(68, 128, 85);
    ellipse(190,113,20,10);//leaves
   ellipse(210,113,20,10);
  ellipse(200,119,10,20);
    ellipse(200,107,10,20);
    
   fill(77, 67, 40); //logs
   rect(220,124,50,5); 
    
    fill(120, 118, 114);
    ellipse(290,119,30,20);//rock
    
   fill(110, 10, 250);//books
  rect(1,40,20,100);
  fill(186, 3, 252);
  rect(20,60,20,80); 
  fill(252, 3, 20);
  rect(40,80,20,60); 
    
    textSize(30);
    fill(31, 7, 247);
    textFont('Arial Black');
    text("My Pet Toby", 120,50);   
}
}

class Kid {
  constructor() {

    this.kidX = width / 3;
    this.kidY = height - 230; 

    fill(0);
    ellipse(114, 122, 150, 150);
  } 


  show() {
    fill(0);
    stroke(0);
    strokeWeight(2);
    fill(222, 213, 175);
    rect(this.kidX + 4, this.kidY + 0.5, 50, 50); //face
    fill(20, 20, 18);
    rect(this.kidX + 17, this.kidY + 17, 9, 9); //right eye
    rect(this.kidX + 37, this.kidY + 17, 9, 9); //left eye
    rect(this.kidX + 20, this.kidY + 33, 20, 10); //mouth
    rect(this.kidX + 4, this.kidY + 50, 50, 50); //body
    fill(255, 20, 50); 
    rect(this.kidX + 50, this.kidY + 40, 50, 60); //right arm



  }

  // move() { 
  //     this.kidX++;
  //     if (this.kidX > width) { 
  //       this.kidX = 0; 
  //     }
  // }
}

/////////
// SCENE 2
// SHOW OUR MOUSE
/////////
class Mouse {

  constructor(x, y) {
    this.mouseX = x;
    this.mouseY = y; 
    this.collect = false; 
    this.canDrawText = false;
  } 

  show() { //only show if mouse has not been collected 
    if (this.collect == false) { 
      fill(143, 137, 137); 
      ellipse(this.mouseX, this.mouseY + 10, 50, 25);
      ellipse(this.mouseX + 26, this.mouseY + 10, 20, 20);
      ellipse(this.mouseX + 21, this.mouseY + 1, 12, 12);
      ellipse(this.mouseX + 33, this.mouseY + 1, 12, 12);

    }
  }

  move() {
    this.mouseX++;
    if (this.mouseX > width) {
      this.mouseX = 0;
    }
  }

  stopShow() { // mouse is collected add to totalmouse count
    this.collect = true;
    this.canDrawText = true;
    this.time = millis()
    totalMouse++; // ++ is adding one to total mouse
    //pTotalMouse = totalMouse; //adding to previous totalMouse
  }

  checkCollision() { //If mouse is not collected then check the space around the mouse 
    if (this.collect == false) {
      if (this.mouseX > kid2.kidX + 35 && this.mouseX < kid2.kidX + 85 && this.mouseY > kid2.kidY + 40 && this.mouseY < kid2.kidY + 100) {
        //rect(this.mouseX, this.mouseY, kid1.kidX, kid1.kidY);
        this.stopShow();

      }
    }
  }
  drawText() {
    if (this.canDrawText) {
      //check the time, if its less than 4 seconds
      if (millis() < this.time + 4000) {
        // if(pTotalMouse == totalMouse) {
        //   print("prev "+pTotalMouse);
        print("time:" + this.time);
        strokeWeight(1);
        textSize(12);
        text("+" + totalMouse, this.mouseX, this.mouseY);
        fill(0); 
      } else { 
        this.canDrawText = false;
      }
    }
  }
}